package com.aman.ftp

import android.app.Application
import com.google.firebase.FirebaseApp
import com.google.firebase.FirebaseOptions
import com.google.firebase.database.FirebaseDatabase

class MyApp : Application() {
    override fun onCreate() {
        super.onCreate()

        // Initialize Firebase
        initializeFirebase(this)
    }

    private fun initializeFirebase(context: Application) {
        // Check if FirebaseApp is already initialized
        if (FirebaseApp.getApps(context).isEmpty()) {
            val options = FirebaseOptions.Builder()
                .setDatabaseUrl("https://console.firebase.google.com/project/ftp-share-1/database/ftp-share-1-default-rtdb/data/~2F")
                .setApiKey("AIzaSyDFEgx-atbz_WQXJxByWv368DOiwl8PbeQ")
                .setApplicationId("1:193247960045:android:b1f1322531eafddc2125e4")
                .build()
            FirebaseApp.initializeApp(context, options)
        }

        // Enable persistence
        FirebaseDatabase.getInstance().setPersistenceEnabled(true)
    }
}
