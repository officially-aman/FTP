package com.aman.ftp

data class User(
    val fullName: String = "",
    val username: String = "",
    val email: String = "",
    val mobileNumber: String = "",
    val password: String = ""
)
